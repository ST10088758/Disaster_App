using Disaster_App.Data;
using Disaster_App.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Xml.Linq;
using Microsoft.Extensions.Primitives;

namespace Disaster_App.Pages
{
    public class DonationPageModel : PageModel
    {
        private readonly DisasterContext _context;
        private readonly ILogger<RegisterModel> _logger;
        private readonly IConfiguration _configuration;

        public DonationPageModel(DisasterContext context, ILogger<RegisterModel> logger, IConfiguration configuration)
        {
            _context = context;
            _logger = logger;
            _configuration = configuration;
        }

        public IActionResult OnPostCaptureMonetaryDonation()
        {
            _logger.LogInformation("money donation");

            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            var moneyDate = Request.Form["moneyDate"];
            var moneyAmount = int.Parse(Request.Form["moneyAmount"]);
            var name = Request.Form["name"];


            if (name == "")
            {
                name = "Anonymous";
            }

            List<MonetaryDonations> moneyDonation = _context.MonetaryDonations.ToList();

            var money = new MonetaryDonations
            {
                DonarName = name,
                DonationDate = moneyDate,
                DonationAmount = moneyAmount

            };

            _context.MonetaryDonations.Add(money);
            _context.SaveChanges();               
            
            return Page();
        }

        public IActionResult OnPostCaptureGoodsDonation()
        {
            _logger.LogInformation("goods donation");

            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            var goodsDate = Request.Form["goodsDate"];
            var goodsAmount = int.Parse(Request.Form["goodsAmount"]);
            var category = Request.Form["category"];
            var itemDescription = Request.Form["itemDescription"];
            var donarName = Request.Form["donarName"];

            _logger.LogInformation(donarName);
            _logger.LogInformation(category);

            if (donarName.Count == 0 || string.IsNullOrEmpty(donarName[0]))
            {
                donarName = "Anonymous";
            }

            _logger.LogInformation(donarName);

            List<GoodsDonations> goodsDonation = _context.GoodsDonations.ToList();

            var goods = new GoodsDonations
            {
                DonationDate = goodsDate,
                DonarName = donarName,
                NumberOfItems = goodsAmount,
                Category = category.ToString(),
                ItemDescription = itemDescription

            };          

            _context.GoodsDonations.Add(goods);
            _context.SaveChanges();

            return Page();
        }

        public IActionResult OnPostCaptureDisaster()
        {
            _logger.LogInformation("disaster");

            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            var startDate = Request.Form["startDate"];
            var endDate = Request.Form["endDate"];
            var disasterDescription = Request.Form["disasterDescription"];
            var disasterLocation = Request.Form["disasterLocation"];
            var aid = Request.Form["aid"];

            List<Disaster> newDisaster = _context.Disaster.ToList();

            var disaster = new Disaster
            {
                StartDate = startDate,
                EndDate = endDate,
                DisasterDescription = disasterDescription,
                DisasterLocation = disasterLocation,
                Aid = aid

            };

            _context.Disaster.Add(disaster);
            _context.SaveChanges();

            return Page();
        }

        /*public IActionResult OnPost()
         {

             _logger.LogInformation("Test donation");

             string connectionString = _configuration.GetConnectionString("DefaultConnection");

             string formId = Request.Form["id"];

             _logger.LogInformation(formId);

             if (formId == "money")
             {
                 _logger.LogInformation("money");

                 var moneyDate = Request.Form["moneyDate"];
                 var moneyAmount = int.Parse(Request.Form["moneyAmount"]);
                 var name = Request.Form["name"];

                 if (name == "")
                 {
                     name = "Anonymous";
                 }

                 List<MonetaryDonations> moneyDonation = _context.MonetaryDonations.ToList();

                 var money = new MonetaryDonations
                 {
                     DonarName = name,
                     DonationDate = moneyDate,
                     DonationAmount = moneyAmount

                 };

                 _context.MonetaryDonations.Add(money);
                 _context.SaveChanges();
             }
             else if (formId == "goods")
             {

                 _logger.LogInformation("goods");

                 var goodsDate = Request.Form["goodsDate"];
                 var goodsAmount = int.Parse(Request.Form["goodsAmount"]);
                 var category = Request.Form["category"];
                 var itemDescription = Request.Form["itemDescription"];
                 var donarName = Request.Form["donarName"];

                 if (donarName == "")
                 {
                     donarName = "Anonymous";
                 }

                 List<GoodsDonations> goodsDonation = _context.GoodsDonations.ToList();

                 var good = new GoodsDonations
                 {
                     DonarName = donarName,
                     NumberOfItems = goodsAmount,
                     Category = category,
                     DonationDate = goodsDate,
                     ItemDescription = itemDescription,
                 };

                 _context.GoodsDonations.Add(good);
                 _context.SaveChanges();
             }
             else if (formId == "disaster")
             {

                 _logger.LogInformation("disaster");

                 var startDate = Request.Form["startDate"];
                 var endDate = Request.Form["endDate"];
                 var disasterDescription = Request.Form["disasterDescription"];
                 var disasterLocation = Request.Form["disasterLocation"];
                 var aid = Request.Form["aid"];

                 List<Disaster> disasterList = _context.Disaster.ToList();

                 var disaster = new Disaster
                 {
                     StartDate = startDate,
                     EndDate = endDate,
                     DisasterDescription = disasterDescription,
                     DisasterLocation = disasterLocation,
                     Aid = aid,

                 };

                 _context.Disaster.Add(disaster);
                 _context.SaveChanges();
             }

             return Page();
         }*/
    }
}
