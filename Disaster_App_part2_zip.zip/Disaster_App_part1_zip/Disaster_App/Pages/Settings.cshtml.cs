using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_App.Pages
{
    public class SettingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
